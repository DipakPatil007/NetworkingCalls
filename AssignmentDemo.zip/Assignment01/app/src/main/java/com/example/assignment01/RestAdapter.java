package com.example.assignment01;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;

public class RestAdapter extends RecyclerView.Adapter<RestAdapter.ViewHolder> {
    Context context;
    ArrayList<DashBoardResponse> arrayList;
    LayoutInflater inflater;
    //  General Class for common functionality 1) like button 2) add into favourite
    GeneralClass generalClass;

    public RestAdapter(Context context, ArrayList<DashBoardResponse> arrayList) {
        this.context = context;
        this.arrayList = arrayList;
        inflater = LayoutInflater.from(context);
        generalClass = new GeneralClass();
    }

    @NonNull
    @Override
    public RestAdapter.ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = inflater.inflate(R.layout.rest_post, parent, false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull RestAdapter.ViewHolder holder, int position) {

        //  Add post into favourite
        holder.favouriteBtn.setOnClickListener(view -> {
            generalClass.addFavourite(context,null,holder,position);
        });

        //  Like post
        holder.likeBtn.setOnClickListener(view -> {
            generalClass.likePost(context,null,holder,position);
        });
    }

    @Override
    public int getItemCount() {
        return arrayList.size();
    }

    public class ViewHolder extends RecyclerView.ViewHolder {

        ImageView profileImg;
        TextView employeeNameTxt;
        TextView toEmployeeNameTxt;
        TextView dateTimeTxt;
        ImageView favouriteBtn;
        ImageView postImg;
        TextView subCommentTxt;
        TextView postTxt;
        ImageView likeBtn;
        TextView likeBtnTxt;
        TextView commentTxt;
        ImageView deletePostBtn;

        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            profileImg = itemView.findViewById(R.id.profile_image);
            employeeNameTxt = itemView.findViewById(R.id.employee_name_txt);
            toEmployeeNameTxt = itemView.findViewById(R.id.to_employee_name_txt);
            dateTimeTxt = itemView.findViewById(R.id.date_txt);
            favouriteBtn = itemView.findViewById(R.id.favourite_btn);
            postImg = itemView.findViewById(R.id.post_image);
            subCommentTxt = itemView.findViewById(R.id.sub_comment_post);
            postTxt = itemView.findViewById(R.id.post_txt);
            likeBtn = itemView.findViewById(R.id.like_btn);
            likeBtnTxt = itemView.findViewById(R.id.like_btn_txt);
            commentTxt = itemView.findViewById(R.id.comment_txt);
            deletePostBtn = itemView.findViewById(R.id.delete_post_btn);
        }
    }


}
