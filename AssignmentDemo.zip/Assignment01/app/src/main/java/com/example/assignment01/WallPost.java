package com.example.assignment01;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.ConcatAdapter;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.os.Bundle;
import java.util.ArrayList;
import java.util.List;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class WallPost extends AppCompatActivity {

    //  List
    ArrayList<DashBoardResponse> listd = new ArrayList<>();
    ArrayList<DashBoardResponse> listb = new ArrayList<>();
    RecyclerView recyclerView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_wall_post);


        recyclerView = findViewById(R.id.recyclerview);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));

        //  wall post request
        RetrofitInstance
                .getInstance()
                .apiInterface
                .loadDiscussionPost("12a35a05-f4af-40d3-bf40-492e44216e97", "2E0FE5FF-51F1-45D9-8862-132A802EF08A", 1, "", 10, false)
                .enqueue(new Callback<List<DashBoardResponse>>() {
                    @Override
                    public void onResponse(Call<List<DashBoardResponse>> call, Response<List<DashBoardResponse>> response) {
                        for (int i=0;i<response.body().size();i++){
                            int postType = response.body().get(i).getPostType();
                            if (postType == 1){
                                //  discussion post
                                listd.add(response.body().get(i));
                            }
                            else if (postType == 5 || postType == 7 || postType == 8){
                                listb.add(response.body().get(i));
                            }
                        }

                        //  Adapter 1
                        DiscussionAdapter discussionAdapter = new DiscussionAdapter(getApplicationContext(),listd);
                        //  Adapter 2
                        RestAdapter restAdapter = new RestAdapter(getApplicationContext(),listb);

                        ConcatAdapter concatAdapter = new ConcatAdapter(discussionAdapter,restAdapter);

                        recyclerView.setAdapter(concatAdapter);
                    }

                    @Override
                    public void onFailure(Call<List<DashBoardResponse>> call, Throwable t) {}
                });
    }
}