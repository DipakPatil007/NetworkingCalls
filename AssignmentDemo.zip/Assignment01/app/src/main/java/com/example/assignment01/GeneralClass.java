package com.example.assignment01;

import android.content.Context;
import android.widget.Toast;

import androidx.core.content.ContextCompat;
import androidx.core.graphics.drawable.DrawableCompat;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class GeneralClass {

    public void addFavourite(Context context, DiscussionAdapter.ViewHolder discussionHolder, RestAdapter.ViewHolder restHolder, int pos) {
        RetrofitInstance
                .getInstance()
                .apiInterface
                .addIntoFavourite("2E0FE5FF-51F1-45D9-8862-132A802EF08A", "12a35a05-f4af-40d3-bf40-492e44216e97", "3488")
                .enqueue(new Callback<FavouriteResponse>() {
                    @Override
                    public void onResponse(Call<FavouriteResponse> call, Response<FavouriteResponse> response) {
                        Toast.makeText(context, "Added into favourite.", Toast.LENGTH_SHORT).show();
                    }

                    @Override
                    public void onFailure(Call<FavouriteResponse> call, Throwable t) {
                    }
                });
    }

    public void likePost(Context context,DiscussionAdapter.ViewHolder disHolder, RestAdapter.ViewHolder restHolder, int pos) {

        if (disHolder != null) {
            if (disHolder.likeBtnTxt.getText() == "Like") {
                DrawableCompat.setTint(DrawableCompat.wrap(disHolder.likeBtn.getDrawable()), ContextCompat.getColor(context,R.color.sky_blue));
                disHolder.likeBtnTxt.setText("UnLike");
            } else {
                DrawableCompat.setTint(DrawableCompat.wrap(disHolder.likeBtn.getDrawable()), ContextCompat.getColor(context,R.color.black));
                disHolder.likeBtnTxt.setText("Like");
            }
        } else {
            if (restHolder.likeBtnTxt.getText() == "Like") {
                DrawableCompat.setTint(DrawableCompat.wrap(restHolder.likeBtn.getDrawable()), ContextCompat.getColor(context,R.color.sky_blue));
                restHolder.likeBtnTxt.setText("UnLike");
            } else {
                DrawableCompat.setTint(DrawableCompat.wrap(restHolder.likeBtn.getDrawable()), ContextCompat.getColor(context,R.color.black
                ));
                restHolder.likeBtnTxt.setText("Like");
            }
        }

        RetrofitInstance
                .getInstance()
                .apiInterface
                .likeThePost("2E0FE5FF-51F1-45D9-8862-132A802EF08A",
                        "12a35a05-f4af-40d3-bf40-492e44216e97",
                        "8A3EDD10-5519-4F91-B55B-66A9620D7997",
                        false,
                        true,
                        0,
                        false)
                .enqueue(new Callback<FavouriteResponse>() {
                    @Override
                    public void onResponse(Call<FavouriteResponse> call, Response<FavouriteResponse> response) {

                    }

                    @Override
                    public void onFailure(Call<FavouriteResponse> call, Throwable t) {
                    }
                });
    }
}
