package com.example.assignment01;

import android.content.Context;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class DiscussionAdapter extends RecyclerView.Adapter<DiscussionAdapter.ViewHolder> {

    Context context;
    ArrayList<DashBoardResponse> arrayList;
    LayoutInflater inflater;
    //  General Class for common functionality 1) like button 2) add into favourite
    GeneralClass generalClass;

    public DiscussionAdapter(Context context, ArrayList<DashBoardResponse> arrayList) {
        this.context = context;
        this.arrayList = arrayList;
        inflater = LayoutInflater.from(context);
        generalClass = new GeneralClass();
    }

    @NonNull
    @Override
    public DiscussionAdapter.ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = inflater.inflate(R.layout.discussion_post_layout, parent, false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull DiscussionAdapter.ViewHolder holder, int position) {
        holder.favouriteBtn.setOnClickListener(view -> {
            //  favourite button function
            generalClass.addFavourite(context,holder,null,position);
        });

        holder.likeBtn.setOnClickListener(view -> {
            //  like post function
            generalClass.likePost(context,holder,null,position);
        });
    }

    @Override
    public int getItemCount() {
        return arrayList.size();
    }

    public static class ViewHolder extends RecyclerView.ViewHolder {

        ImageView profileImg;
        TextView employeeNameTxt;
        TextView toEmployeeNameTxt;
        TextView dateTimeTxt;
        ImageView favouriteBtn;
        ImageView postImg;
        TextView postTxt;
        ImageView likeBtn;
        TextView likeBtnTxt;
        TextView commentTxt;
        ImageView deletePostBtn;

        public ViewHolder(@NonNull View itemView) {
            super(itemView);

            profileImg = itemView.findViewById(R.id.profile_image);
            employeeNameTxt = itemView.findViewById(R.id.employee_name_txt);
            toEmployeeNameTxt = itemView.findViewById(R.id.to_employee_name_txt);
            dateTimeTxt = itemView.findViewById(R.id.date_txt);
            favouriteBtn = itemView.findViewById(R.id.favourite_btn);
            postImg = itemView.findViewById(R.id.post_image);
            postTxt = itemView.findViewById(R.id.post_txt);
            likeBtn = itemView.findViewById(R.id.like_btn);
            likeBtnTxt = itemView.findViewById(R.id.like_btn_txt);
            commentTxt = itemView.findViewById(R.id.comment_txt);
            deletePostBtn = itemView.findViewById(R.id.delete_post_btn);
        }
    }

}
