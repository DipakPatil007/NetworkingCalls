package com.example.assignment01;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;

import com.google.android.material.progressindicator.CircularProgressIndicator;

public class SplashScreen extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_splash_screen);
        CircularProgressIndicator circularProgressIndicator = findViewById(R.id.circularProgressIndicator);
        circularProgressIndicator.setVisibility(View.VISIBLE);
    }
}