package com.example.assignment01;
import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

public class DashBoardResponse {

    @SerializedName("PostId")
    @Expose
    private Integer postId;
    @SerializedName("Count")
    @Expose
    private Integer count;
    @SerializedName("FromUserId")
    @Expose
    private Integer fromUserId;
    @SerializedName("ThumbnailImage")
    @Expose
    private String thumbnailImage;
    @SerializedName("FriendName")
    @Expose
    private String friendName;
    @SerializedName("FriendPost")
    @Expose
    private String friendPost;
    @SerializedName("Comment")
    @Expose
    private String comment;
    @SerializedName("FilePath")
    @Expose
    private String filePath;
    @SerializedName("ToolTipCreationDate")
    @Expose
    private String toolTipCreationDate;
    @SerializedName("FormattedCreationDate")
    @Expose
    private String formattedCreationDate;
    @SerializedName("ToUserId")
    @Expose
    private Integer toUserId;
    @SerializedName("Post")
    @Expose
    private String post;
    @SerializedName("PostType")
    @Expose
    private Integer postType;
    @SerializedName("PollId")
    @Expose
    private Integer pollId;
    @SerializedName("PollQuestion")
    @Expose
    private String pollQuestion;
    @SerializedName("BdayGiftId")
    @Expose
    private Integer bdayGiftId;
    @SerializedName("PokeId")
    @Expose
    private Integer pokeId;
    @SerializedName("AwardId")
    @Expose
    private Integer awardId;
    @SerializedName("UserIcon")
    @Expose
    private String userIcon;
    @SerializedName("LikeCount")
    @Expose
    private Integer likeCount;
    @SerializedName("CommentCount")
    @Expose
    private Integer commentCount;
    @SerializedName("FeedCode")
    @Expose
    private String feedCode;
    @SerializedName("LikeStatus")
    @Expose
    private String likeStatus;
    @SerializedName("LoginUserIcon")
    @Expose
    private String loginUserIcon;
    @SerializedName("FavoriteUrl")
    @Expose
    private String favoriteUrl;
    @SerializedName("FavoriteTitle")
    @Expose
    private String favoriteTitle;
    @SerializedName("MentionsUserIds")
    @Expose
    private String mentionsUserIds;
    @SerializedName("TemperoryImage")
    @Expose
    private String temperoryImage;
    @SerializedName("FileName")
    @Expose
    private String fileName;
    @SerializedName("VerificationCode")
    @Expose
    private String verificationCode;
    @SerializedName("BirthdayMessage")
    @Expose
    private String birthdayMessage;
    @SerializedName("BirthdayImage")
    @Expose
    private String birthdayImage;
    @SerializedName("BirthdayWishCount")
    @Expose
    private String birthdayWishCount;
    @SerializedName("TempWallPostId")
    @Expose
    private Integer tempWallPostId;
    @SerializedName("ToUserName")
    @Expose
    private String toUserName;
    @SerializedName("ToUserVerificationCode")
    @Expose
    private String toUserVerificationCode;
    @SerializedName("Question")
    @Expose
    private String question;
    @SerializedName("OptionOne")
    @Expose
    private String optionOne;
    @SerializedName("OptionTwo")
    @Expose
    private String optionTwo;
    @SerializedName("OptionThree")
    @Expose
    private String optionThree;
    @SerializedName("OptionFour")
    @Expose
    private String optionFour;
    @SerializedName("OptionFive")
    @Expose
    private String optionFive;
    @SerializedName("OptionSix")
    @Expose
    private String optionSix;
    @SerializedName("OptionCount")
    @Expose
    private Integer optionCount;
    @SerializedName("SelectedOption")
    @Expose
    private String selectedOption;
    @SerializedName("VoteCountOne")
    @Expose
    private Integer voteCountOne;
    @SerializedName("VoteCountTwo")
    @Expose
    private Integer voteCountTwo;
    @SerializedName("VoteCountThree")
    @Expose
    private Integer voteCountThree;
    @SerializedName("VoteCountFour")
    @Expose
    private Integer voteCountFour;
    @SerializedName("VoteCountFive")
    @Expose
    private Integer voteCountFive;
    @SerializedName("VoteCountSix")
    @Expose
    private Integer voteCountSix;
    @SerializedName("IsVoted")
    @Expose
    private Integer isVoted;
    @SerializedName("TotalPollCount")
    @Expose
    private Integer totalPollCount;
    @SerializedName("TotalPollVote")
    @Expose
    private String totalPollVote;
    @SerializedName("PercentOne")
    @Expose
    private String percentOne;
    @SerializedName("PercentTwo")
    @Expose
    private String percentTwo;
    @SerializedName("PercentThree")
    @Expose
    private String percentThree;
    @SerializedName("PercentFour")
    @Expose
    private String percentFour;
    @SerializedName("PercentFive")
    @Expose
    private String percentFive;
    @SerializedName("PercentSix")
    @Expose
    private String percentSix;
    @SerializedName("PollOpt")
    @Expose
    private String pollOpt;
    @SerializedName("PollRes")
    @Expose
    private String pollRes;
    @SerializedName("TdOne")
    @Expose
    private String tdOne;
    @SerializedName("TdTwo")
    @Expose
    private String tdTwo;
    @SerializedName("TdThree")
    @Expose
    private String tdThree;
    @SerializedName("TdFour")
    @Expose
    private String tdFour;
    @SerializedName("TdFive")
    @Expose
    private String tdFive;
    @SerializedName("TdSix")
    @Expose
    private String tdSix;
    @SerializedName("SpVotes")
    @Expose
    private String spVotes;
    @SerializedName("ViewResult")
    @Expose
    private String viewResult;
    @SerializedName("LnkVote")
    @Expose
    private String lnkVote;
    @SerializedName("LnkResult")
    @Expose
    private String lnkResult;
    @SerializedName("LnkReload")
    @Expose
    private String lnkReload;
    @SerializedName("InTdOne")
    @Expose
    private String inTdOne;
    @SerializedName("InTdTwo")
    @Expose
    private String inTdTwo;
    @SerializedName("InTdThree")
    @Expose
    private String inTdThree;
    @SerializedName("InTdFour")
    @Expose
    private String inTdFour;
    @SerializedName("InTdFive")
    @Expose
    private String inTdFive;
    @SerializedName("InTdSix")
    @Expose
    private String inTdSix;
    @SerializedName("QuestionClientSideId")
    @Expose
    private String questionClientSideId;
    @SerializedName("RdoOne")
    @Expose
    private String rdoOne;
    @SerializedName("RdoTwo")
    @Expose
    private String rdoTwo;
    @SerializedName("RdoThree")
    @Expose
    private String rdoThree;
    @SerializedName("RdoFour")
    @Expose
    private String rdoFour;
    @SerializedName("RdoFive")
    @Expose
    private String rdoFive;
    @SerializedName("RdoSix")
    @Expose
    private String rdoSix;
    @SerializedName("BtnVote")
    @Expose
    private String btnVote;
    @SerializedName("ImageId")
    @Expose
    private String imageId;
    @SerializedName("NameId")
    @Expose
    private String nameId;
    @SerializedName("TimeId")
    @Expose
    private String timeId;
    @SerializedName("VisibleFour")
    @Expose
    private String visibleFour;
    @SerializedName("VisibleFive")
    @Expose
    private String visibleFive;
    @SerializedName("VisibleSix")
    @Expose
    private String visibleSix;
    @SerializedName("LnkChangeVote")
    @Expose
    private String lnkChangeVote;
    @SerializedName("WallPstId")
    @Expose
    private Integer wallPstId;
    @SerializedName("VisibleOption")
    @Expose
    private String visibleOption;
    @SerializedName("VisibleGraph")
    @Expose
    private String visibleGraph;
    @SerializedName("VoteVisible")
    @Expose
    private String voteVisible;
    @SerializedName("LnkVotes")
    @Expose
    private String lnkVotes;
    @SerializedName("PollDisplay")
    @Expose
    private String pollDisplay;
    @SerializedName("ImgLoader")
    @Expose
    private String imgLoader;
    @SerializedName("BirthdayDisplay")
    @Expose
    private String birthdayDisplay;
    @SerializedName("ImageDisplay")
    @Expose
    private String imageDisplay;
    @SerializedName("ShowVideo")
    @Expose
    private String showVideo;
    @SerializedName("ShowImage")
    @Expose
    private String showImage;
    @SerializedName("ShowImageOrVideoSection")
    @Expose
    private String showImageOrVideoSection;
    @SerializedName("LinkUrl")
    @Expose
    private String linkUrl;
    @SerializedName("LinkTitle")
    @Expose
    private String linkTitle;
    @SerializedName("LinkDescription")
    @Expose
    private String linkDescription;
    @SerializedName("LinkImage")
    @Expose
    private String linkImage;
    @SerializedName("LinkDisplay")
    @Expose
    private String linkDisplay;
    @SerializedName("LinkImageDisplay")
    @Expose
    private String linkImageDisplay;
    @SerializedName("CategoryIds")
    @Expose
    private String categoryIds;
    @SerializedName("CategoryString")
    @Expose
    private String categoryString;
    @SerializedName("CategoryName")
    @Expose
    private String categoryName;
    @SerializedName("NextHalfPost")
    @Expose
    private String nextHalfPost;
    @SerializedName("ShowSeeMoreLink")
    @Expose
    private String showSeeMoreLink;
    @SerializedName("OriginalImageData")
    @Expose
    private String originalImageData;
    @SerializedName("ThumbnailImageData")
    @Expose
    private String thumbnailImageData;
    @SerializedName("Key")
    @Expose
    private String key;
    @SerializedName("MessageCount")
    @Expose
    private Integer messageCount;
    @SerializedName("NotificationCount")
    @Expose
    private Integer notificationCount;
    @SerializedName("IsFollowing")
    @Expose
    private Boolean isFollowing;
    @SerializedName("FollowPostUrl")
    @Expose
    private String followPostUrl;
    @SerializedName("FollowPostTitle")
    @Expose
    private String followPostTitle;
    @SerializedName("SubDomainValue")
    @Expose
    private String subDomainValue;
    @SerializedName("IsVideo")
    @Expose
    private Boolean isVideo;
    @SerializedName("IsDocument")
    @Expose
    private Boolean isDocument;
    @SerializedName("IsAudio")
    @Expose
    private Boolean isAudio;
    @SerializedName("ArticleId")
    @Expose
    private Integer articleId;
    @SerializedName("GroupId")
    @Expose
    private Integer groupId;
    @SerializedName("ProjectId")
    @Expose
    private Integer projectId;
    @SerializedName("GroupName")
    @Expose
    private String groupName;
    @SerializedName("ProjectName")
    @Expose
    private String projectName;
    @SerializedName("GroupCode")
    @Expose
    private String groupCode;
    @SerializedName("ProjectCode")
    @Expose
    private String projectCode;
    @SerializedName("GroupNameDisplay")
    @Expose
    private String groupNameDisplay;
    @SerializedName("ProjectNameDisplay")
    @Expose
    private String projectNameDisplay;
    @SerializedName("TaskEndDate")
    @Expose
    private String taskEndDate;
    @SerializedName("IsCompletedStatus")
    @Expose
    private String isCompletedStatus;
    @SerializedName("IsCheckBoxShow")
    @Expose
    private String isCheckBoxShow;
    @SerializedName("TaskId")
    @Expose
    private Integer taskId;
    @SerializedName("IsTaskDisplay")
    @Expose
    private String isTaskDisplay;
    @SerializedName("TaskName")
    @Expose
    private String taskName;
    @SerializedName("IsPostDisplay")
    @Expose
    private String isPostDisplay;
    @SerializedName("LibraryFileName")
    @Expose
    private String libraryFileName;
    @SerializedName("IsETAShow")
    @Expose
    private String isETAShow;
    @SerializedName("ProjectIds")
    @Expose
    private String projectIds;
    @SerializedName("LibraryMappingId")
    @Expose
    private String libraryMappingId;

    public Integer getPostId() {
        return postId;
    }

    public void setPostId(Integer postId) {
        this.postId = postId;
    }

    public Integer getCount() {
        return count;
    }

    public void setCount(Integer count) {
        this.count = count;
    }

    public Integer getFromUserId() {
        return fromUserId;
    }

    public void setFromUserId(Integer fromUserId) {
        this.fromUserId = fromUserId;
    }

    public String getThumbnailImage() {
        return thumbnailImage;
    }

    public void setThumbnailImage(String thumbnailImage) {
        this.thumbnailImage = thumbnailImage;
    }

    public String getFriendName() {
        return friendName;
    }

    public void setFriendName(String friendName) {
        this.friendName = friendName;
    }

    public String getFriendPost() {
        return friendPost;
    }

    public void setFriendPost(String friendPost) {
        this.friendPost = friendPost;
    }

    public String getComment() {
        return comment;
    }

    public void setComment(String comment) {
        this.comment = comment;
    }

    public String getFilePath() {
        return filePath;
    }

    public void setFilePath(String filePath) {
        this.filePath = filePath;
    }

    public String getToolTipCreationDate() {
        return toolTipCreationDate;
    }

    public void setToolTipCreationDate(String toolTipCreationDate) {
        this.toolTipCreationDate = toolTipCreationDate;
    }

    public String getFormattedCreationDate() {
        return formattedCreationDate;
    }

    public void setFormattedCreationDate(String formattedCreationDate) {
        this.formattedCreationDate = formattedCreationDate;
    }

    public Integer getToUserId() {
        return toUserId;
    }

    public void setToUserId(Integer toUserId) {
        this.toUserId = toUserId;
    }

    public String getPost() {
        return post;
    }

    public void setPost(String post) {
        this.post = post;
    }

    public Integer getPostType() {
        return postType;
    }

    public void setPostType(Integer postType) {
        this.postType = postType;
    }

    public Integer getPollId() {
        return pollId;
    }

    public void setPollId(Integer pollId) {
        this.pollId = pollId;
    }

    public String getPollQuestion() {
        return pollQuestion;
    }

    public void setPollQuestion(String pollQuestion) {
        this.pollQuestion = pollQuestion;
    }

    public Integer getBdayGiftId() {
        return bdayGiftId;
    }

    public void setBdayGiftId(Integer bdayGiftId) {
        this.bdayGiftId = bdayGiftId;
    }

    public Integer getPokeId() {
        return pokeId;
    }

    public void setPokeId(Integer pokeId) {
        this.pokeId = pokeId;
    }

    public Integer getAwardId() {
        return awardId;
    }

    public void setAwardId(Integer awardId) {
        this.awardId = awardId;
    }

    public String getUserIcon() {
        return userIcon;
    }

    public void setUserIcon(String userIcon) {
        this.userIcon = userIcon;
    }

    public Integer getLikeCount() {
        return likeCount;
    }

    public void setLikeCount(Integer likeCount) {
        this.likeCount = likeCount;
    }

    public Integer getCommentCount() {
        return commentCount;
    }

    public void setCommentCount(Integer commentCount) {
        this.commentCount = commentCount;
    }

    public String getFeedCode() {
        return feedCode;
    }

    public void setFeedCode(String feedCode) {
        this.feedCode = feedCode;
    }

    public String getLikeStatus() {
        return likeStatus;
    }

    public void setLikeStatus(String likeStatus) {
        this.likeStatus = likeStatus;
    }

    public String getLoginUserIcon() {
        return loginUserIcon;
    }

    public void setLoginUserIcon(String loginUserIcon) {
        this.loginUserIcon = loginUserIcon;
    }

    public String getFavoriteUrl() {
        return favoriteUrl;
    }

    public void setFavoriteUrl(String favoriteUrl) {
        this.favoriteUrl = favoriteUrl;
    }

    public String getFavoriteTitle() {
        return favoriteTitle;
    }

    public void setFavoriteTitle(String favoriteTitle) {
        this.favoriteTitle = favoriteTitle;
    }

    public String getMentionsUserIds() {
        return mentionsUserIds;
    }

    public void setMentionsUserIds(String mentionsUserIds) {
        this.mentionsUserIds = mentionsUserIds;
    }

    public String getTemperoryImage() {
        return temperoryImage;
    }

    public void setTemperoryImage(String temperoryImage) {
        this.temperoryImage = temperoryImage;
    }

    public String getFileName() {
        return fileName;
    }

    public void setFileName(String fileName) {
        this.fileName = fileName;
    }

    public String getVerificationCode() {
        return verificationCode;
    }

    public void setVerificationCode(String verificationCode) {
        this.verificationCode = verificationCode;
    }

    public String getBirthdayMessage() {
        return birthdayMessage;
    }

    public void setBirthdayMessage(String birthdayMessage) {
        this.birthdayMessage = birthdayMessage;
    }

    public String getBirthdayImage() {
        return birthdayImage;
    }

    public void setBirthdayImage(String birthdayImage) {
        this.birthdayImage = birthdayImage;
    }

    public String getBirthdayWishCount() {
        return birthdayWishCount;
    }

    public void setBirthdayWishCount(String birthdayWishCount) {
        this.birthdayWishCount = birthdayWishCount;
    }

    public Integer getTempWallPostId() {
        return tempWallPostId;
    }

    public void setTempWallPostId(Integer tempWallPostId) {
        this.tempWallPostId = tempWallPostId;
    }

    public String getToUserName() {
        return toUserName;
    }

    public void setToUserName(String toUserName) {
        this.toUserName = toUserName;
    }

    public String getToUserVerificationCode() {
        return toUserVerificationCode;
    }

    public void setToUserVerificationCode(String toUserVerificationCode) {
        this.toUserVerificationCode = toUserVerificationCode;
    }

    public String getQuestion() {
        return question;
    }

    public void setQuestion(String question) {
        this.question = question;
    }

    public String getOptionOne() {
        return optionOne;
    }

    public void setOptionOne(String optionOne) {
        this.optionOne = optionOne;
    }

    public String getOptionTwo() {
        return optionTwo;
    }

    public void setOptionTwo(String optionTwo) {
        this.optionTwo = optionTwo;
    }

    public String getOptionThree() {
        return optionThree;
    }

    public void setOptionThree(String optionThree) {
        this.optionThree = optionThree;
    }

    public String getOptionFour() {
        return optionFour;
    }

    public void setOptionFour(String optionFour) {
        this.optionFour = optionFour;
    }

    public String getOptionFive() {
        return optionFive;
    }

    public void setOptionFive(String optionFive) {
        this.optionFive = optionFive;
    }

    public String getOptionSix() {
        return optionSix;
    }

    public void setOptionSix(String optionSix) {
        this.optionSix = optionSix;
    }

    public Integer getOptionCount() {
        return optionCount;
    }

    public void setOptionCount(Integer optionCount) {
        this.optionCount = optionCount;
    }

    public String getSelectedOption() {
        return selectedOption;
    }

    public void setSelectedOption(String selectedOption) {
        this.selectedOption = selectedOption;
    }

    public Integer getVoteCountOne() {
        return voteCountOne;
    }

    public void setVoteCountOne(Integer voteCountOne) {
        this.voteCountOne = voteCountOne;
    }

    public Integer getVoteCountTwo() {
        return voteCountTwo;
    }

    public void setVoteCountTwo(Integer voteCountTwo) {
        this.voteCountTwo = voteCountTwo;
    }

    public Integer getVoteCountThree() {
        return voteCountThree;
    }

    public void setVoteCountThree(Integer voteCountThree) {
        this.voteCountThree = voteCountThree;
    }

    public Integer getVoteCountFour() {
        return voteCountFour;
    }

    public void setVoteCountFour(Integer voteCountFour) {
        this.voteCountFour = voteCountFour;
    }

    public Integer getVoteCountFive() {
        return voteCountFive;
    }

    public void setVoteCountFive(Integer voteCountFive) {
        this.voteCountFive = voteCountFive;
    }

    public Integer getVoteCountSix() {
        return voteCountSix;
    }

    public void setVoteCountSix(Integer voteCountSix) {
        this.voteCountSix = voteCountSix;
    }

    public Integer getIsVoted() {
        return isVoted;
    }

    public void setIsVoted(Integer isVoted) {
        this.isVoted = isVoted;
    }

    public Integer getTotalPollCount() {
        return totalPollCount;
    }

    public void setTotalPollCount(Integer totalPollCount) {
        this.totalPollCount = totalPollCount;
    }

    public String getTotalPollVote() {
        return totalPollVote;
    }

    public void setTotalPollVote(String totalPollVote) {
        this.totalPollVote = totalPollVote;
    }

    public String getPercentOne() {
        return percentOne;
    }

    public void setPercentOne(String percentOne) {
        this.percentOne = percentOne;
    }

    public String getPercentTwo() {
        return percentTwo;
    }

    public void setPercentTwo(String percentTwo) {
        this.percentTwo = percentTwo;
    }

    public String getPercentThree() {
        return percentThree;
    }

    public void setPercentThree(String percentThree) {
        this.percentThree = percentThree;
    }

    public String getPercentFour() {
        return percentFour;
    }

    public void setPercentFour(String percentFour) {
        this.percentFour = percentFour;
    }

    public String getPercentFive() {
        return percentFive;
    }

    public void setPercentFive(String percentFive) {
        this.percentFive = percentFive;
    }

    public String getPercentSix() {
        return percentSix;
    }

    public void setPercentSix(String percentSix) {
        this.percentSix = percentSix;
    }

    public String getPollOpt() {
        return pollOpt;
    }

    public void setPollOpt(String pollOpt) {
        this.pollOpt = pollOpt;
    }

    public String getPollRes() {
        return pollRes;
    }

    public void setPollRes(String pollRes) {
        this.pollRes = pollRes;
    }

    public String getTdOne() {
        return tdOne;
    }

    public void setTdOne(String tdOne) {
        this.tdOne = tdOne;
    }

    public String getTdTwo() {
        return tdTwo;
    }

    public void setTdTwo(String tdTwo) {
        this.tdTwo = tdTwo;
    }

    public String getTdThree() {
        return tdThree;
    }

    public void setTdThree(String tdThree) {
        this.tdThree = tdThree;
    }

    public String getTdFour() {
        return tdFour;
    }

    public void setTdFour(String tdFour) {
        this.tdFour = tdFour;
    }

    public String getTdFive() {
        return tdFive;
    }

    public void setTdFive(String tdFive) {
        this.tdFive = tdFive;
    }

    public String getTdSix() {
        return tdSix;
    }

    public void setTdSix(String tdSix) {
        this.tdSix = tdSix;
    }

    public String getSpVotes() {
        return spVotes;
    }

    public void setSpVotes(String spVotes) {
        this.spVotes = spVotes;
    }

    public String getViewResult() {
        return viewResult;
    }

    public void setViewResult(String viewResult) {
        this.viewResult = viewResult;
    }

    public String getLnkVote() {
        return lnkVote;
    }

    public void setLnkVote(String lnkVote) {
        this.lnkVote = lnkVote;
    }

    public String getLnkResult() {
        return lnkResult;
    }

    public void setLnkResult(String lnkResult) {
        this.lnkResult = lnkResult;
    }

    public String getLnkReload() {
        return lnkReload;
    }

    public void setLnkReload(String lnkReload) {
        this.lnkReload = lnkReload;
    }

    public String getInTdOne() {
        return inTdOne;
    }

    public void setInTdOne(String inTdOne) {
        this.inTdOne = inTdOne;
    }

    public String getInTdTwo() {
        return inTdTwo;
    }

    public void setInTdTwo(String inTdTwo) {
        this.inTdTwo = inTdTwo;
    }

    public String getInTdThree() {
        return inTdThree;
    }

    public void setInTdThree(String inTdThree) {
        this.inTdThree = inTdThree;
    }

    public String getInTdFour() {
        return inTdFour;
    }

    public void setInTdFour(String inTdFour) {
        this.inTdFour = inTdFour;
    }

    public String getInTdFive() {
        return inTdFive;
    }

    public void setInTdFive(String inTdFive) {
        this.inTdFive = inTdFive;
    }

    public String getInTdSix() {
        return inTdSix;
    }

    public void setInTdSix(String inTdSix) {
        this.inTdSix = inTdSix;
    }

    public String getQuestionClientSideId() {
        return questionClientSideId;
    }

    public void setQuestionClientSideId(String questionClientSideId) {
        this.questionClientSideId = questionClientSideId;
    }

    public String getRdoOne() {
        return rdoOne;
    }

    public void setRdoOne(String rdoOne) {
        this.rdoOne = rdoOne;
    }

    public String getRdoTwo() {
        return rdoTwo;
    }

    public void setRdoTwo(String rdoTwo) {
        this.rdoTwo = rdoTwo;
    }

    public String getRdoThree() {
        return rdoThree;
    }

    public void setRdoThree(String rdoThree) {
        this.rdoThree = rdoThree;
    }

    public String getRdoFour() {
        return rdoFour;
    }

    public void setRdoFour(String rdoFour) {
        this.rdoFour = rdoFour;
    }

    public String getRdoFive() {
        return rdoFive;
    }

    public void setRdoFive(String rdoFive) {
        this.rdoFive = rdoFive;
    }

    public String getRdoSix() {
        return rdoSix;
    }

    public void setRdoSix(String rdoSix) {
        this.rdoSix = rdoSix;
    }

    public String getBtnVote() {
        return btnVote;
    }

    public void setBtnVote(String btnVote) {
        this.btnVote = btnVote;
    }

    public String getImageId() {
        return imageId;
    }

    public void setImageId(String imageId) {
        this.imageId = imageId;
    }

    public String getNameId() {
        return nameId;
    }

    public void setNameId(String nameId) {
        this.nameId = nameId;
    }

    public String getTimeId() {
        return timeId;
    }

    public void setTimeId(String timeId) {
        this.timeId = timeId;
    }

    public String getVisibleFour() {
        return visibleFour;
    }

    public void setVisibleFour(String visibleFour) {
        this.visibleFour = visibleFour;
    }

    public String getVisibleFive() {
        return visibleFive;
    }

    public void setVisibleFive(String visibleFive) {
        this.visibleFive = visibleFive;
    }

    public String getVisibleSix() {
        return visibleSix;
    }

    public void setVisibleSix(String visibleSix) {
        this.visibleSix = visibleSix;
    }

    public String getLnkChangeVote() {
        return lnkChangeVote;
    }

    public void setLnkChangeVote(String lnkChangeVote) {
        this.lnkChangeVote = lnkChangeVote;
    }

    public Integer getWallPstId() {
        return wallPstId;
    }

    public void setWallPstId(Integer wallPstId) {
        this.wallPstId = wallPstId;
    }

    public String getVisibleOption() {
        return visibleOption;
    }

    public void setVisibleOption(String visibleOption) {
        this.visibleOption = visibleOption;
    }

    public String getVisibleGraph() {
        return visibleGraph;
    }

    public void setVisibleGraph(String visibleGraph) {
        this.visibleGraph = visibleGraph;
    }

    public String getVoteVisible() {
        return voteVisible;
    }

    public void setVoteVisible(String voteVisible) {
        this.voteVisible = voteVisible;
    }

    public String getLnkVotes() {
        return lnkVotes;
    }

    public void setLnkVotes(String lnkVotes) {
        this.lnkVotes = lnkVotes;
    }

    public String getPollDisplay() {
        return pollDisplay;
    }

    public void setPollDisplay(String pollDisplay) {
        this.pollDisplay = pollDisplay;
    }

    public String getImgLoader() {
        return imgLoader;
    }

    public void setImgLoader(String imgLoader) {
        this.imgLoader = imgLoader;
    }

    public String getBirthdayDisplay() {
        return birthdayDisplay;
    }

    public void setBirthdayDisplay(String birthdayDisplay) {
        this.birthdayDisplay = birthdayDisplay;
    }

    public String getImageDisplay() {
        return imageDisplay;
    }

    public void setImageDisplay(String imageDisplay) {
        this.imageDisplay = imageDisplay;
    }

    public String getShowVideo() {
        return showVideo;
    }

    public void setShowVideo(String showVideo) {
        this.showVideo = showVideo;
    }

    public String getShowImage() {
        return showImage;
    }

    public void setShowImage(String showImage) {
        this.showImage = showImage;
    }

    public String getShowImageOrVideoSection() {
        return showImageOrVideoSection;
    }

    public void setShowImageOrVideoSection(String showImageOrVideoSection) {
        this.showImageOrVideoSection = showImageOrVideoSection;
    }

    public String getLinkUrl() {
        return linkUrl;
    }

    public void setLinkUrl(String linkUrl) {
        this.linkUrl = linkUrl;
    }

    public String getLinkTitle() {
        return linkTitle;
    }

    public void setLinkTitle(String linkTitle) {
        this.linkTitle = linkTitle;
    }

    public String getLinkDescription() {
        return linkDescription;
    }

    public void setLinkDescription(String linkDescription) {
        this.linkDescription = linkDescription;
    }

    public String getLinkImage() {
        return linkImage;
    }

    public void setLinkImage(String linkImage) {
        this.linkImage = linkImage;
    }

    public String getLinkDisplay() {
        return linkDisplay;
    }

    public void setLinkDisplay(String linkDisplay) {
        this.linkDisplay = linkDisplay;
    }

    public String getLinkImageDisplay() {
        return linkImageDisplay;
    }

    public void setLinkImageDisplay(String linkImageDisplay) {
        this.linkImageDisplay = linkImageDisplay;
    }

    public String getCategoryIds() {
        return categoryIds;
    }

    public void setCategoryIds(String categoryIds) {
        this.categoryIds = categoryIds;
    }

    public String getCategoryString() {
        return categoryString;
    }

    public void setCategoryString(String categoryString) {
        this.categoryString = categoryString;
    }

    public String getCategoryName() {
        return categoryName;
    }

    public void setCategoryName(String categoryName) {
        this.categoryName = categoryName;
    }

    public String getNextHalfPost() {
        return nextHalfPost;
    }

    public void setNextHalfPost(String nextHalfPost) {
        this.nextHalfPost = nextHalfPost;
    }

    public String getShowSeeMoreLink() {
        return showSeeMoreLink;
    }

    public void setShowSeeMoreLink(String showSeeMoreLink) {
        this.showSeeMoreLink = showSeeMoreLink;
    }

    public String getOriginalImageData() {
        return originalImageData;
    }

    public void setOriginalImageData(String originalImageData) {
        this.originalImageData = originalImageData;
    }

    public String getThumbnailImageData() {
        return thumbnailImageData;
    }

    public void setThumbnailImageData(String thumbnailImageData) {
        this.thumbnailImageData = thumbnailImageData;
    }

    public String getKey() {
        return key;
    }

    public void setKey(String key) {
        this.key = key;
    }

    public Integer getMessageCount() {
        return messageCount;
    }

    public void setMessageCount(Integer messageCount) {
        this.messageCount = messageCount;
    }

    public Integer getNotificationCount() {
        return notificationCount;
    }

    public void setNotificationCount(Integer notificationCount) {
        this.notificationCount = notificationCount;
    }

    public Boolean getIsFollowing() {
        return isFollowing;
    }

    public void setIsFollowing(Boolean isFollowing) {
        this.isFollowing = isFollowing;
    }

    public String getFollowPostUrl() {
        return followPostUrl;
    }

    public void setFollowPostUrl(String followPostUrl) {
        this.followPostUrl = followPostUrl;
    }

    public String getFollowPostTitle() {
        return followPostTitle;
    }

    public void setFollowPostTitle(String followPostTitle) {
        this.followPostTitle = followPostTitle;
    }

    public String getSubDomainValue() {
        return subDomainValue;
    }

    public void setSubDomainValue(String subDomainValue) {
        this.subDomainValue = subDomainValue;
    }

    public Boolean getIsVideo() {
        return isVideo;
    }

    public void setIsVideo(Boolean isVideo) {
        this.isVideo = isVideo;
    }

    public Boolean getIsDocument() {
        return isDocument;
    }

    public void setIsDocument(Boolean isDocument) {
        this.isDocument = isDocument;
    }

    public Boolean getIsAudio() {
        return isAudio;
    }

    public void setIsAudio(Boolean isAudio) {
        this.isAudio = isAudio;
    }

    public Integer getArticleId() {
        return articleId;
    }

    public void setArticleId(Integer articleId) {
        this.articleId = articleId;
    }

    public Integer getGroupId() {
        return groupId;
    }

    public void setGroupId(Integer groupId) {
        this.groupId = groupId;
    }

    public Integer getProjectId() {
        return projectId;
    }

    public void setProjectId(Integer projectId) {
        this.projectId = projectId;
    }

    public String getGroupName() {
        return groupName;
    }

    public void setGroupName(String groupName) {
        this.groupName = groupName;
    }

    public String getProjectName() {
        return projectName;
    }

    public void setProjectName(String projectName) {
        this.projectName = projectName;
    }

    public String getGroupCode() {
        return groupCode;
    }

    public void setGroupCode(String groupCode) {
        this.groupCode = groupCode;
    }

    public String getProjectCode() {
        return projectCode;
    }

    public void setProjectCode(String projectCode) {
        this.projectCode = projectCode;
    }

    public String getGroupNameDisplay() {
        return groupNameDisplay;
    }

    public void setGroupNameDisplay(String groupNameDisplay) {
        this.groupNameDisplay = groupNameDisplay;
    }

    public String getProjectNameDisplay() {
        return projectNameDisplay;
    }

    public void setProjectNameDisplay(String projectNameDisplay) {
        this.projectNameDisplay = projectNameDisplay;
    }

    public String getTaskEndDate() {
        return taskEndDate;
    }

    public void setTaskEndDate(String taskEndDate) {
        this.taskEndDate = taskEndDate;
    }

    public String getIsCompletedStatus() {
        return isCompletedStatus;
    }

    public void setIsCompletedStatus(String isCompletedStatus) {
        this.isCompletedStatus = isCompletedStatus;
    }

    public String getIsCheckBoxShow() {
        return isCheckBoxShow;
    }

    public void setIsCheckBoxShow(String isCheckBoxShow) {
        this.isCheckBoxShow = isCheckBoxShow;
    }

    public Integer getTaskId() {
        return taskId;
    }

    public void setTaskId(Integer taskId) {
        this.taskId = taskId;
    }

    public String getIsTaskDisplay() {
        return isTaskDisplay;
    }

    public void setIsTaskDisplay(String isTaskDisplay) {
        this.isTaskDisplay = isTaskDisplay;
    }

    public String getTaskName() {
        return taskName;
    }

    public void setTaskName(String taskName) {
        this.taskName = taskName;
    }

    public String getIsPostDisplay() {
        return isPostDisplay;
    }

    public void setIsPostDisplay(String isPostDisplay) {
        this.isPostDisplay = isPostDisplay;
    }

    public String getLibraryFileName() {
        return libraryFileName;
    }

    public void setLibraryFileName(String libraryFileName) {
        this.libraryFileName = libraryFileName;
    }

    public String getIsETAShow() {
        return isETAShow;
    }

    public void setIsETAShow(String isETAShow) {
        this.isETAShow = isETAShow;
    }

    public String getProjectIds() {
        return projectIds;
    }

    public void setProjectIds(String projectIds) {
        this.projectIds = projectIds;
    }

    public String getLibraryMappingId() {
        return libraryMappingId;
    }

    public void setLibraryMappingId(String libraryMappingId) {
        this.libraryMappingId = libraryMappingId;
    }

}