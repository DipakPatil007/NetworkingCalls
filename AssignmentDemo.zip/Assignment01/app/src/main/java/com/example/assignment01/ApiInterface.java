package com.example.assignment01;

import java.util.List;

import retrofit2.Call;
import retrofit2.http.Field;
import retrofit2.http.FormUrlEncoded;
import retrofit2.http.GET;
import retrofit2.http.POST;

public interface ApiInterface {

    //  Get Wall Post Response
    @FormUrlEncoded
    @POST("WallPost/GetWallPostMobile")
    Call<List<DashBoardResponse>> loadDiscussionPost(
            @Field("verificationCode") String verificationCode,
            @Field("key") String key,
            @Field("pageIndex") int pageIndex,
            @Field("toVerificationCode") String toVerificationCode,
            @Field("postCount") int postCount,
            @Field("isFollowing") boolean isFollowing
    );

    //  Add the post into favourite
    @FormUrlEncoded
    @POST("WallPost/AddToFavouritePost")
    Call<FavouriteResponse> addIntoFavourite(
            @Field("key") String key,
            @Field("verificationCode") String verificationCode,
            @Field("postId") String postId
    );

    //  Like the post change the text
    @FormUrlEncoded
    @POST("Mobile/ChangeLikeStatusMobile")
    Call<FavouriteResponse> likeThePost(
            @Field("key") String key,
            @Field("verificationCode") String verificationCode,
            @Field("feedCode") String feedCode,
            @Field("likeStatus") boolean likeStatus,
            @Field("likeStatusSpecified") boolean likeStatusSpecified,
            @Field("commentId") int commentId,
            @Field("commentIdSpecified") boolean commentIdSpecified
    );

}
